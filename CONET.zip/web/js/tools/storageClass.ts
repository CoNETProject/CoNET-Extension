class storageClass {
    public BrowerObject = chrome || browser || null
    public storage: chrome.storage.LocalStorageArea = this.BrowerObject ? this.BrowerObject.storage : null
    constructor () {
        
    }
}