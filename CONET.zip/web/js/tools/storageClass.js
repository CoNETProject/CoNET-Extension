class storageClass {
    constructor() {
        this.BrowerObject = chrome || browser || null;
        this.storage = this.BrowerObject ? this.BrowerObject.storage : null;
    }
}
