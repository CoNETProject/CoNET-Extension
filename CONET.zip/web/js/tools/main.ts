
const BrowerObject = chrome || browser || null
let GlobalStorageObject = null
if ( BrowerObject ) {
    const openMyPage = () => {
        BrowerObject.tabs.create({
            "url": "/web/main.html"
        })
    }
    
    BrowerObject.browserAction.onClicked.addListener( openMyPage )
}
